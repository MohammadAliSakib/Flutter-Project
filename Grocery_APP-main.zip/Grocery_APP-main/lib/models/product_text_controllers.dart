import 'package:flutter/material.dart';

class ProductTextControllers {
  final TextEditingController mrp;
  final TextEditingController sp;
  final TextEditingController size;

  ProductTextControllers(this.mrp, this.sp, this.size);
}
