package com.example.grocery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
