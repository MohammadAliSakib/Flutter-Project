import 'package:flutter/material.dart';

const base_url = "https://api.weatherapi.com/v1/forecast.json?key=6fdc9a1458be4bf4bbe164718242808";

