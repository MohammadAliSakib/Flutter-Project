package com.example.medi_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
