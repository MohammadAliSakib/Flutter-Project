

import 'package:flutter/material.dart';

class MessageScreen extends StatelessWidget {
  //const MessageScreen({super.key});
     List imgs=[
        "doctor1.jpg",
         "doctor2.jpg", 
          "doctor3.jpg",
           "doctor4.jpg",
            "doctor1.jpg",
             "doctor2.jpg",
      ];

  @override
  Widget build(BuildContext context) {


    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,

        children: [
          SizedBox(height: 40),
          Padding(padding: EdgeInsets.symmetric(horizontal: 20),
          child: Text(
            "Messages",
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
            ),
          ),
          ),
          SizedBox(height: 30),
          Padding(
            padding:EdgeInsets.symmetric(horizontal: 15), 
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 10,
                    spreadRadius: 2,
                  )
                ]
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 300,
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 15),
                      child: TextFormField(
                        decoration: InputDecoration(
                          hintText: "Search",
                          border: InputBorder.none,
                        ),
                      ),),
                  )
                ],
              ),
            ),
            ),
        ],
      ),
    );
  }
}